INSERT INTO ruoyi.sys_user_post (user_id, post_id) VALUES (1, 1);
INSERT INTO ruoyi.sys_user_post (user_id, post_id) VALUES (2, 2);
