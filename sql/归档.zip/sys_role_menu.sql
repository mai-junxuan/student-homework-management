INSERT INTO ruoyi.sys_role_menu (role_id, menu_id) VALUES (2, 2000);
