INSERT INTO ruoyi.sys_role_dept (role_id, dept_id) VALUES (2, 100);
INSERT INTO ruoyi.sys_role_dept (role_id, dept_id) VALUES (2, 101);
INSERT INTO ruoyi.sys_role_dept (role_id, dept_id) VALUES (2, 105);
